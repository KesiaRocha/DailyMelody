var express = require('express');
var router = express.Router();

/* GET albuns listing. */
router.get('/', function(req, res, next) {
  res.send("albuns", {title: 'Albuns'});
});

module.exports = router;
