var express = require('express');
var router = express.Router();

/* GET podcasts listing. */
router.get('/', function(req, res, next) {
  res.send("podcasts", {title: 'Podcasts'});
});

module.exports = router;
