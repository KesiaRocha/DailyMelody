function Musics() {
window.location.href = "musics";

}

const iframeCodes = [
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/0RjsbmAOQzWOq3fxQ002rX?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"  loading="lazy"></iframe>',
    `<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/0wqjfojWuTcbEvwaizvTMw?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>`,
    `<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/0aJnGEZWIc1VCYlZOXv05a?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>`,
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/6l8EXrFMXWeHaEutYhwl98?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/3oylWMc9TTC6Nx4I6U3axc?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/5vBnIcG7nD3XEt8ErHpytO?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/3HgoCO9wWuPcNhz8Ip4C46?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/7GYzQIMfdDWo2XC4BDLHPk?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/4D63HSKclSLyE4p9ThvI9U?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/0c1yNi1MuGlcNrCzU2kDVE?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/41U6Qbx5KxhHYIuwlK3lXA?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/4BqgQ4TDBmwJTLYr0YLECX?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/3jkLKeTkRsRehIUkPFHubG?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/6wRy2dydFytIzBlEqVa5sh?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/2fWuaeiOHl60xAQ1kUoyK4?utm_source=generator&theme=0" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/0FZK97MXMm5mUQ8mtudjuK?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/5JpH5T1sCYnUyZD6TM0QaY?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/0Ikw6ho559687KCPbSjr0K?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/2yI4m5Yu2tl8v0It5P9WVz?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/42cH7mrkfljkqkxA2Ip9Xq?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/0e1WaSNDZnoPixaxDNdWo4?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/4LH4d3cOWNNsVw41Gqt2kv?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/3I9Z1nDCL4E0cP62flcbI5?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/15uKqLeki8fZuLdR44Qtz8?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/4VZ7jhV0wHpoNPCB7Vmiml?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/6ApYSpXF8GxZAgBTHDzYge?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/0ujHQ5WCLuKJQXOqXpGtpf?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/4u2Ut8mOhdYkn5aGJiL4Fa?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/07ZKO0mYA9IqVlgWWqJAia?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/album/661Hz0qJK8WIp7vAWsqKvk?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',

];


function getRandomIframeCode() {
    const randomIndex = Math.floor(Math.random() * iframeCodes.length);
    return iframeCodes[randomIndex];
}

document.addEventListener('DOMContentLoaded', function () {
    const randomizeBtn = document.getElementById('randomizeBtn');
    const linkContainer = document.getElementById('linkContainer');

    randomizeBtn.addEventListener('click', function () {
        const randomIframeCode = getRandomIframeCode();

      
        linkContainer.innerHTML = randomIframeCode;
    });
});


