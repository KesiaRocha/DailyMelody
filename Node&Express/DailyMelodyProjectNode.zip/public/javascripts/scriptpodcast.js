
const iframeCodes = [
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/22Wgt4ASeaw8mmoqAWNUn1?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/1k2AsiW1iHQBnqOVcmmWDW?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/14jalMOh1Jr77eTRUdN6X9/video?utm_source=generator" width="624" height="351" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/2Jonxe5ibaFY0iw7Czyioj?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/0IixtNTZ2OvtW0ldsu6OnC?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/7EZp7RdSTHpYdNEOYVAq3K?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/1UwQDriNoZ7YvRj1QguEIK?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/2XCrxZKrm9yOEwcxF6Ka3v?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/5Yl4ao85LeyLc56nvm1E2T?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/2HuFd4vu8PsXGnJLvdPCb6?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/5KqK8MhQbDOXDzljiuJtzB?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/6eMairLQRdKPPKVbcoxSIV?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/7apNtr3lenzrd8SMp0wccO?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/2I0zMvOszKVoIxLaekb6aH?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/0EJ2xJBZ2nzaMscm0YO6FY?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/3QtkKYLAca6NIPx4yWwpsU?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/0rOatMqaG3wB5BF4AdsrSX?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/3YnEI4EIFekrndbYz9rO2s?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/0gGecUGgPd546V7QAjrb9W?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
    
];


function getRandomIframeCode() {
    const randomIndex = Math.floor(Math.random() * iframeCodes.length);
    return iframeCodes[randomIndex];
}


document.addEventListener('DOMContentLoaded', function () {
    const randomizeBtn = document.getElementById('randomizeBtn');
    const linkContainer = document.getElementById('linkContainer');

    randomizeBtn.addEventListener('click', function () {
        const randomIframeCode = getRandomIframeCode();


        linkContainer.innerHTML = randomIframeCode;
    });
});
