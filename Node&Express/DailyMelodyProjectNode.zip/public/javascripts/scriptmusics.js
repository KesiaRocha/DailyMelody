
const iframeCodes = [
    '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/3F4lHPNHlvr3RpO4tpVOIs?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/5OehhztxLfJeCxUMbFfPy6?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/3FdopY118eIYv5COjji7Sa?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/463r5bsN1VqGXtaMctn4Rr?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/05QXjyZgsAq6J84J6SlbyV?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/2RoYgkPzUY0vY7lhUuyus1?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/1wizHJqbqe0YsAkRWN1QBP?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/2Rlso2ZNV0PaWwUYeeBYxx?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/2UG99niAHF6REY08eqHQY8?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/71GYyH4bJ9EpRzTqRsv7jJ?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/6k0X05danQOXSBTVek5DU1?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/46WaBBaEHzgbN88Ew0nh50?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/7po7c8LzxTZ0ybU41qT5gD?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/4gMgiXfqyzZLMhsksGmbQV?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/3G7MgLuWLzUJQflWOCDZit?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/6aPXjtda2SdTi8rAcFlrOS?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/5HLzF5IwHdQflsQVcgnE17?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/04S1pkp1VaIqjg8zZqknR5?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/4R2kfaDFhslZEMJqAFNpdd?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/1BxfuPKGuaTgP7aM0Bbdwr?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/0hTrQoqDmFnA4S1PC265e1?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/0afhq8XCExXpqazXczTSve?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/7qiZfU4dY1lWllzX7mPBI3?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/5w7wuzMzsDer96KqxafeRK?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',
'<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/4RVwu0g32PAqgUiJoXsdF8?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>',

    
];


function getRandomIframeCode() {
    const randomIndex = Math.floor(Math.random() * iframeCodes.length);
    return iframeCodes[randomIndex];
}


document.addEventListener('DOMContentLoaded', function () {
    const randomizeBtn = document.getElementById('randomizeBtn');
    const linkContainer = document.getElementById('linkContainer');

    randomizeBtn.addEventListener('click', function () {
        const randomIframeCode = getRandomIframeCode();


        linkContainer.innerHTML = randomIframeCode;
    });
});
