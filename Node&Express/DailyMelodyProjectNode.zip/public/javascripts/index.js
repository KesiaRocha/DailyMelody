
const randomizeButton = document.getElementById('randomizeButton');


const categories = ['musics', 'podcasts', 'albums'];


randomizeButton.addEventListener('click', function () {

    const randomIndex = Math.floor(Math.random() * categories.length);


    const randomCategory = categories[randomIndex];


    window.location.href = `#${randomCategory}`;
});
